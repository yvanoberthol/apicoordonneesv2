import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LocationComponent} from './components/location/location.component';
import {StateComponent} from './components/state/state.component';
import {CountryComponent} from './components/country/country.component';

const routes: Routes = [
  {path: 'cities', component: LocationComponent},
  {path: 'countries', component: CountryComponent},
  {path: 'states', component: StateComponent},
  { path: '', redirectTo: '/cities', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
