import {Address} from './address';
import {BoundingBox} from './bounding-box';
import {PolygonPoint} from './polygon-point';
import {Coordinate} from './coordinate';

export class City {
  osm_id;
  place_id;
  name;
  county;
  coordinate: Coordinate;
  display_name;
  stateName;

  boundingBox: BoundingBox;
  polygonPoints: PolygonPoint[];
}
