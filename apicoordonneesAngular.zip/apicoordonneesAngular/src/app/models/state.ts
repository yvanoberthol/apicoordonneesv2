import {BoundingBox} from './bounding-box';

export class State {
  id;
  name;
  countryName;
  boundingBox: BoundingBox;
}
