import {BoundingBox} from './bounding-box';

export class Country {
  id;
  name;
  countryCode;
  boundingBox: BoundingBox;
}
