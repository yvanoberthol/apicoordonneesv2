import {State} from './state';

export class Address {
  city;
  county;
  state: State;
}
