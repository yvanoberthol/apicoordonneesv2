export class PolygonPoint {
  x;
  y;
}
