export class BoundingBox {
  southLatitude;
  northLatitude;
  westLongitude;
  eastLongitude;
}
