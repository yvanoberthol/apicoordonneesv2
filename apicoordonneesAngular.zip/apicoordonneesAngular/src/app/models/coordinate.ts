export class Coordinate {
  latitude;
  longitude;
}
