import { Component, OnInit } from '@angular/core';
import {LocationService} from '../../services/location.service';
import {City} from '../../models/city';
import {BoundingBox} from '../../models/bounding-box';
import {PolygonPoint} from '../../models/polygon-point';
import {State} from '../../models/state';
import {Coordinate} from '../../models/coordinate';
import {state} from '@angular/animations';
import {isArray} from 'util';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})
export class LocationComponent implements OnInit {

  motcle = '';
  msg = false;
  cities;
  locationfound;
  constructor(private locationService: LocationService) { }

  ngOnInit() {
  }

  getLocations(motcle) {
    this.locationService.getLocations(motcle).subscribe(
      (data: any) => {
        this.locationfound = data[0];
        this.cities = data;
        console.log(this.locationfound);
        this.msg = true;
      }, error1 => {
        console.log(error1);
      }
    );
  }

  addLocation(data) {
    const cityAdd = new City();
    cityAdd.osm_id = data.osm_id;
    cityAdd.place_id = data.place_id;

    cityAdd.name = data.address.city;
    cityAdd.county = data.address.county;

    const coordinate = new Coordinate();
    coordinate.latitude = data.lat;
    coordinate.longitude = data.lon;

    cityAdd.coordinate = coordinate;

    cityAdd.display_name = data.display_name;
    cityAdd.stateName = data.address.state;

    const boundingBox = new BoundingBox();
    boundingBox.southLatitude = data.boundingbox[0];
    boundingBox.northLatitude = data.boundingbox[1];
    boundingBox.westLongitude = data.boundingbox[2];
    boundingBox.eastLongitude = data.boundingbox[3];

    cityAdd.boundingBox = boundingBox;

    const polygonPoints = [];

    const geojson = data.geojson;
    if (geojson.type == 'Point') {
      if (this.cities[1].geojson.type != 'Point') {
        if (this.cities[1].geojson.type == 'Polygon') {
          this.cities[1].geojson.coordinates[0].forEach(polygonPoint => {
            const polygon = new PolygonPoint();
            polygon.x = polygonPoint[0];
            polygon.y = polygonPoint[1];
            polygonPoints.push(polygon);
          });
        } else if (this.cities[1].geojson.type == 'MultiPolygon') {
          this.cities[1].geojson.coordinates.forEach(multiPolygonPoint => {
            multiPolygonPoint[0].forEach(polygonPoint => {
              const polygon = new PolygonPoint();
              polygon.x = polygonPoint[0];
              polygon.y = polygonPoint[1];
              polygonPoints.push(polygon);
            });
          });
        }
      } else {
        console.log('y\'a pas de polygon ni de multipolygon');
      }
    } else if (geojson.type == 'Polygon') {
      geojson.coordinates[0].forEach(polygonPoint => {
        const polygon = new PolygonPoint();
        polygon.x = polygonPoint[0];
        polygon.y = polygonPoint[1];
        polygonPoints.push(polygon);
      });
    } else if (geojson.type == 'MultiPolygon') {
      geojson.coordinates.forEach(multiPolygonPoint => {
        multiPolygonPoint[0].forEach(polygonPoint => {
          const polygon = new PolygonPoint();
          polygon.x = polygonPoint[0];
          polygon.y = polygonPoint[1];
          polygonPoints.push(polygon);
        });
      });
    }

    cityAdd.polygonPoints = polygonPoints;
    console.log(cityAdd);

    this.locationService.addLocation(cityAdd).subscribe(
      () => {
        console.log('ok');
        this.msg = false;
      }
    );
  }

}
