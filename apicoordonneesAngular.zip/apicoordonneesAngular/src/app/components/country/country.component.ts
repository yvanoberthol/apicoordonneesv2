import { Component, OnInit } from '@angular/core';
import {PolygonPoint} from '../../models/polygon-point';
import {BoundingBox} from '../../models/bounding-box';
import {CountryService} from '../../services/country.service';
import {Country} from '../../models/country';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {

  motcle = '';
  msg = false;
  countryfound;
  constructor(private countryService: CountryService) { }

  ngOnInit() {
  }

  getCountries(motcle) {
    this.countryService.getCountries(motcle).subscribe(
      (data: any) => {
        this.countryfound = data[0];
        console.log(this.countryfound);
        this.msg = true;
      }, error1 => {
        console.log(error1);
      }
    );
  }

  addCountry(data) {
    const countryAdd = new Country();
    countryAdd.name = data.address.country;
    countryAdd.countryCode = data.address.country_code;

    const boundingBox = new BoundingBox();
    boundingBox.southLatitude = data.boundingbox[0];
    boundingBox.northLatitude = data.boundingbox[1];
    boundingBox.westLongitude = data.boundingbox[2];
    boundingBox.eastLongitude = data.boundingbox[3];

    countryAdd.boundingBox = boundingBox;

    console.log(countryAdd);
    this.countryService.addCountry(countryAdd).subscribe(
      () => {
        console.log('ok');
        this.msg = false;
      }
    );
  }
}
