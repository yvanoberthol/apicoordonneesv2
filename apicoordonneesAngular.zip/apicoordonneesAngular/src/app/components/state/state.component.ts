import { Component, OnInit } from '@angular/core';
import {BoundingBox} from '../../models/bounding-box';
import {StateService} from '../../services/state.service';
import {State} from '../../models/state';
import {PolygonPoint} from '../../models/polygon-point';

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.css']
})
export class StateComponent implements OnInit {

  motcle = '';
  msg = false;
  statefound;
  constructor(private stateService: StateService) { }

  ngOnInit() {
  }

  getStates(motcle) {
    this.stateService.getStates(motcle).subscribe(
      (data: any) => {
        this.statefound = data[0];
        console.log(this.statefound);
        this.msg = true;
      }, error1 => {
        console.log(error1);
      }
    );
  }

  addState(data) {
    const stateAdd = new State();
    stateAdd.name = data.address.state;
    stateAdd.countryName = data.address.country;

    const boundingBox = new BoundingBox();
    boundingBox.southLatitude = data.boundingbox[0];
    boundingBox.northLatitude = data.boundingbox[1];
    boundingBox.westLongitude = data.boundingbox[2];
    boundingBox.eastLongitude = data.boundingbox[3];

    stateAdd.boundingBox = boundingBox;

    console.log(stateAdd);

    this.stateService.addState(stateAdd).subscribe(
      () => {
        console.log('ok');
        this.msg = false;
      }
    );
  }
}
