import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {City} from '../models/city';

@Injectable({
  providedIn: 'root'
})
export class LocationService {
  urlback = 'http://localhost:8085/cities';
  url = 'http://nominatim.openstreetmap.org/search/cm?format=json&polygon_geojson=1&addressdetails=1&country=cameroon&city=';
  constructor(private http: HttpClient) { }

  public getLocations(motcle) {
    return this.http.get(this.url + motcle);
  }

  public addLocation(location: City) {
    return this.http.post(this.urlback + '/add', location);
  }
}
