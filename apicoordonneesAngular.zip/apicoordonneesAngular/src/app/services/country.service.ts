import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Country} from '../models/country';

@Injectable({
  providedIn: 'root'
})
export class CountryService {
  urlback = 'http://localhost:8085/countries';
  url = 'https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&country=';
  constructor(private http: HttpClient) { }
  public getCountries(motcle) {
    return this.http.get(this.url + motcle);
  }

  public addCountry(country: Country) {
    return this.http.post(this.urlback, country);
  }
}
