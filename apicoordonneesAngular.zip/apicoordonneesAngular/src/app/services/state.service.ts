import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {State} from '../models/state';

@Injectable({
  providedIn: 'root'
})
export class StateService {
  urlback = 'http://localhost:8085/states';
  url = 'https://nominatim.openstreetmap.org/search/cm?format=json&addressdetails=1&country=cameroon&state=';
  constructor(private http: HttpClient) { }
  public getStates(motcle) {
    return this.http.get(this.url + motcle);
  }

  public addState(state: State) {
    return this.http.post(this.urlback + '/add', state);
  }
}
